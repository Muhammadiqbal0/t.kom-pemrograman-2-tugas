<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="css/style.css" > -->
    <link rel="stylesheet" href="css\bootstrap.min.css">
</head>
<body>
<div class="p-3 mb-2 bg-dark text-white">
  <ul>
    <h1 class="fw-bold fst-italic">
        <?php require_once "Blog/Blog.php";
	    $titel1 = new Blog();
        echo $titel1->title;?>
    </h1>    
    <p class="fw-light">
        <?php $paragrap1 = new Blog();
        echo $paragrap1->paragraph1();?>
    </p>
    <a class="text-reset" href="/">
            <?php $a = new Blog();
            echo $a->link();?>
    </a>
  </ul>
</div>
<ol>
    <h1 class="fw-bold">
        <?php $titel2 = new Blog();
        echo $titel2->title2; ?>
    </h1>
        <?php $tg = new Blog();
        echo $tg->date; ?>
    <a href="/">
        <?php $lk = new Blog();
        echo $lk->time(); ?>
    </a>
    <br>
    <br/>
    <p >
        <?php $jk = new Blog();
        echo $jk->information1(); ?>
    </p>

    <p class="lh-sm">
        <?php $jk = new Blog();
        echo $jk->information2(); 
        $jk = new Blog();
        echo $jk->besar(); 
        $jk = new Blog();
        echo $jk->info(); ?>
    </p>
    <p class="lh-sm">
        <?php $jk = new Blog();
        echo $jk->info3(); ?>
    </p>
</ol>
</body>
</html>

