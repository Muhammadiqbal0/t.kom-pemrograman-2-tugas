<?php

abstract class Cv {

    abstract function getIsiCv();
        //untuk class Biodata
        public function pengenalan() {
            return "Nama saya Muhammad Iqbal berbekalkan ilmu dari 
            Institut Teknologi dan Sains Nahdatul Ulama Kalimantan 
            saya berusaha membantu apa saja yang anda inginkan sesuai dengan 
            keahlian saya sebagai back end developer.";
         }
         //untuk class Pendidikan
        public function keteranganPendidikan(){
            return "IPS ( Ilmu Pengetahuan Sosial )";
        }
        //untuk class pengalaman
        public function pengalaman1(){
            return "membuatkan website tentang pengenalan data diri";
        }
        public function keahlian1(){
            return "Menguasai Javascript";
        }
        public function suka4(){
            return "traveling";
        }
}