<?php
require_once "Cv/Cv.php";
class Pengalaman extends Cv {
    public $judul2="PENGALAMAN";
    public $tahun1 = "2022 <br> <b> Freelancer.co.id </b>";
    public $tahun2 = "2023 <br> <b> Tugas Kampus </b>";
    public function getIsiCv(){
        $str = parent::pengalaman1();
        return $str;
        }
        public function pengalaman01(){
            return "Mendesain website e-commer";
        } 
        public function pengalaman2(){
            return "Membuat website blog pribadi";
        }
        public function pengalaman3(){
            return "Mebuat CV berbentuk website";
        }
}