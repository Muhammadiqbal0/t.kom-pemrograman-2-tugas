<?php
require_once "Cv/Cv.php";
class Keahlian extends Cv {
public $judul5="KEAHLIAN";
public $bisa1 = "Menguasai HTML";
public $bisa2 = "Menguasai CSS";
public $bisa3 = "Menguasai OOP PHP";
public function getIsiCv(){
    $str = parent::keahlian();
    return $str;
    }
}
