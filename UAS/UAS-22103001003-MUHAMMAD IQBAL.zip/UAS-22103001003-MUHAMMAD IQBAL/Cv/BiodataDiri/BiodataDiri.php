<?php
require_once "Cv/Cv.php";
class BiodataDiri extends Cv {
    public $judul1="KONTAK";
    public $nama = "MUHAMMAD IQBAL";
    public $kerja = "WEB DEVELOPER & WEB DESIGNER";
    public $nomorTelpon = "+628 2272 0669 86";
    public $email = "mhmmdiqbal20210@gmail.com";
    public $instagram = "@w1tyie";

    public function getIsiCv(){
        $str = "-" . parent::pengenalan() . "-" ;
        return $str;
        }
    }