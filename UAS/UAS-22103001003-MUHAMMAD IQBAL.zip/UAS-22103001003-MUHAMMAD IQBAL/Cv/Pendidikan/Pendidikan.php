<?php
require_once "Cv/Cv.php";
class Pendidikan extends Cv{
    public $judul3="PENDIDIKAN";
    public $pendidikanTerakhir = "2015-2021 <br> MA Darul Amin";
    public $pendidikanSekarang = "2022-2025 <br> ITS NU Kalimantan";

    public function getIsiCv(){
        $str = parent::keteranganPendidikan();
        return $str;
        }
        public function keteranganPendidikan2(){
            return "S1 ( Teknik Komputer )";
        }
}