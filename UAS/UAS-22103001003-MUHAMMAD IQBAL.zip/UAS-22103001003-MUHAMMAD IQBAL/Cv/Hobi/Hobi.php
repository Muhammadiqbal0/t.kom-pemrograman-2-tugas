<?php
require_once "Cv/Cv.php";
class Hobi extends Cv {
    public $judul4="HOBI";
    public $suka1 = "Futsal";
    public $suka2 = "Mendengar Musik";
    public $suka3 = "Belajar";

    public function getIsiCv(){
        $str = parent::suka4();
        return $str;
        }
}